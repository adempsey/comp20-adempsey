var express = require("express");
var app = express(express.logger());
app.use(express.bodyParser());
app.set('title', 'nodeapp');

var mongoUri = process.env.MONGOLAB_URI ||
	process.env.MONGOHQ_URL ||
	'mongodb://admin:mongoisok@alex.mongohq.com:10094/app14901887';
var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function(error, databaseConnection) {
	db = databaseConnection;
});

app.configure(function() {
	app.use(express.methodOverride());
	app.use(express.bodyParser());
	app.use(function(request, response, next) {
		response.header("Access-Control-Allow-Origin", "*");
		response.header("Access-Control-Allow-Headers", "X-Requested-With");
		next();
	});
	app.use(app.router);
});

app.all('/', function(request, response, next) {
	response.header("Access-Control-Allow-Origin", "*");
	response.header("Access-Control-Allow-Headers", "X-Requested-With");
	next();
});

app.get('/', function(request, response, next) {
	response.set('Content-Type', 'text/html');
	db.collection("highscores", function(er, collection) {
		collection.find({}).toArray(function(err, results) {
			var res_text = "<h1>Scores:<\/h1><ul>";
			var length = results.length;
			for (var i = 0; i < length; i++) {
				res_text += "<li><strong>" + results[i]["game_title"].toUpperCase() + "<\/strong>: " 
						    + results[i]["username"] + ": "  + results[i]["score"] + ", " 
							+ results[i]["created_at"] + "<\/li>";
			}
			res_text += "<\/ul>";
			response.send(res_text);
		});
	});
});

app.post('/submit.json', function(request, response, next) {
	var d = new Date();
	var n = d.toString();
	var scorenum = Number(request.body.score);
	db.collection("highscores", function(er, collection) {
		collection.insert( {game_title: request.body.game_title,
							  username: request.body.username,
							     score: scorenum,
							created_at: n
						}); 
	});
});

app.get('/highscores.json', function(request, response) {
	response.set('Content-Type', 'text/json');
	db.collection("highscores", function(er, collection) {
		collection.find({game_title: request.query["game_title"]}).sort({score:-1}).limit(10).toArray(function(err, results) {
			response.send(results);
		});
	});
});

app.get('/usersearch', function(request, response) {
	response.set('Content-Type', 'text/html');
	response.send("<h1>Usersearch<\/h1><form name='input' action='search' method='get'><input type='text' id='input' name='username' \/><input type='submit' id='submit' \/></form>");
});

app.get('/search', function(request, response) {
	response.set('Content-Type', 'text/html');
	db.collection("highscores", function(er, collection) {
		collection.find({username: request.query["username"]}).toArray(function(err, results) {
			var length = results.length;
			var res_text = "<ul>"
			for (var i = 0; i < length; i++) {
				res_text += "<li><strong>" + results[i]["game_title"].toUpperCase() + "<\/strong>: "
							+ results[i]["score"] + ", " + results[i]["created_at"] + "<\/li>";
			}
			res_text += "<\/ul>";
			response.send(res_text);
		});
	});
});

var port = process.env.PORT || 5000;
app.listen(port, function() {
	console.log("Listening on " + port);
});
