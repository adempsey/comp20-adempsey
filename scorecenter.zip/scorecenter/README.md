All components of assignment should be correctly implemented.
Did not collaborate or discuss with anyone.
Approximately 12 hours were spent on this assignment.
